# React + Vite

https://www.figma.com/file/QwJfbRyorJ9UFCvWDMvUJ7/Assignment?type=design&node-id=0%3A1&mode=design&t=vB9bQPXxV6k5dwv3-1

Recreate the provided design using React and Tailwind CSS.
